<!DOCTYPE html>
<html>
<head>
	<title>LOGIN with CRUD</title>
</head>
<body>
	
	<script type="text/javascript">
		window.location.replace("login.php");
	</script>

</body>
</html>