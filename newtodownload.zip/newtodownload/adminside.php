 <div class="quixnav">           
                <div class="quixnav-scroll">
                    <ul class="metismenu" id="menu">
                        <li class="nav-label">Navigation</li>
                        <li><a href="home.php"><i class="mdi mdi-home"></i><span class="nav-text">Home</span></a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="mdi mdi-file-document-box"></i><span class="nav-text">Farm Records</span></a>
                            <ul aria-expanded="false">
                                <li><a href="updatefarm.php">Update Farm Record</a></li>
                                <li><a href="createfarm.php">View And Create Farm</a></li>
                           
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="mdi mdi-file-document-box"></i><span class="nav-text">Rearing And Hatching</span></a>
                            <ul aria-expanded="false">
                                <li><a href="hatching.php">Rearing Record</a></li>
                                <li><a href="rearing.php">Hatching Farm</a></li>
                           
                            </ul>
                        </li>
    
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="mdi mdi-table"></i><span class="nav-text">Store Record</span></a>
                            <ul aria-expanded="false">
                                <li><a href="updatestore.php">Update Store Record</a></li>
                                <li><a href="viewstore.php">View Store Record</a></li>
                            </ul>
                        </li>
                        <li><a href="createadmin.php" aria-expanded="false"><i class="mdi mdi-widgets"></i><span class="nav-text">Create Admin</span></a></li>
                        
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false"><i class="mdi mdi-earth"></i><span class="nav-text">Manage Customer</span></a>
                            <ul aria-expanded="false">
                                <li><a href="createcustomer.php">Create Customer</a></li>
                                <li><a href="customer-record.php">View Customer Record</a></li>
                            </ul>
                        </li>
                         <li><a href="logout.php" aria-expanded="false"><i class="mdi mdi-widgets"></i><span class="nav-text">Logout</span></a></li>
    
                    </ul>
                </div>
            </div>