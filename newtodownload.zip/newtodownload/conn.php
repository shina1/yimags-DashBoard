<?php  
$severname = "localhost";
$username = "yimalbur_owner";
$password = "qaz1234wsX";
$dbname = "yimalbur_dataBase";

$conn = mysqli_connect($severname,$username,$password,$dbname);

if (!$conn) {
	die("connection failed" . mysqli_connect_error());
}
?>