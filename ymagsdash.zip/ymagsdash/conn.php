<?php  
$severname = "localhost";
$username = "root";
$password = "";
$dbname = "farm";

$conn = mysqli_connect($severname,$username,$password,$dbname);

if (!$conn) {
	die("connection failed" . mysqli_connect_error());
}

?>