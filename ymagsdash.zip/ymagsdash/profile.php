<!DOCTYPE html>
<html lang="en-US">
 <head>
<!-- Basic Page Info -->
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<meta name="theme-color" content="#5a00f0" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
	<link rel="profile" href="http://gmpg.org/xfn/11">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<!-- Favicon -->
			<link rel="shortcut icon" href="https://quixlab.com/wp-content/uploads/2019/03/favicon.png" type="image/x-icon" />
			    <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-87715829-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-87715829-1');
</script>

<title>Page not found &#8211; QuixLab</title>
<link rel='dns-prefetch' href='//code.tidio.co' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="QuixLab &raquo; Feed" href="https://quixlab.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="QuixLab &raquo; Comments Feed" href="https://quixlab.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/quixlab.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.1.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='https://quixlab.com/wp-includes/css/dist/block-library/style.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://quixlab.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='cookie-notice-front-css'  href='https://quixlab.com/wp-content/plugins/cookie-notice/css/front.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='edd-styles-css'  href='https://quixlab.com/wp-content/plugins/easy-digital-downloads/templates/edd.min.css?ver=2.9.11' type='text/css' media='all' />
<link rel='stylesheet' id='dashicons-css'  href='https://quixlab.com/wp-includes/css/dashicons.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='edd-reviews-css'  href='https://quixlab.com/wp-content/plugins/edd-reviews/assets/css/edd-reviews.min.css?ver=2.1.9' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-parent-style-css'  href='https://quixlab.com/wp-content/themes/mayosis/style.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-style-css'  href='https://quixlab.com/wp-content/themes/mayosis-child/style.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-essential-css'  href='https://quixlab.com/wp-content/themes/mayosis/css/essential.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='mayosis-main-style-css'  href='https://quixlab.com/wp-content/themes/mayosis/css/main.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='zeroicon-line-css'  href='https://quixlab.com/wp-content/themes/mayosis/css/zero-icon-line.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='font-awesome-css'  href='https://quixlab.com/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/font-awesome.min.css?ver=5.6' type='text/css' media='all' />
<link rel='stylesheet' id='kirki-styles-mayo_config-css'  href='https://quixlab.com/wp-content/plugins/mayosis-core/library/kirki/assets/css/kirki-styles.css?ver=5.1.1' type='text/css' media='all' />
<style id='kirki-styles-mayo_config-inline-css' type='text/css'>
.cart-style-one .cart-button .edd-cart-quantity, .cart_top_1 > .navbar-nav > li > a.login-button, .main-header .login-button:hover,.sidemenu-login .login-button, .header-search-form .download_cat_filter, .header-search-form .search-btn::after, header .product-search-form .mayosis_vendor_cat{background:#5a00f0;}.cart-style-one .cart-button .edd-cart-quantity, .cart_top_1 > .navbar-nav > li > a.login-button, .main-header .login-button:hover,.sidemenu-login .login-button, .header-search-form .download_cat_filter, .header-search-form .search-btn::after, header .product-search-form .mayosis_vendor_cat,.header-search-form input[type="text"],.product-search-form.header-search-form input[type="text"]{border-color:#5a00f0;}.cart-style-one .cart-button .edd-cart-quantity, .cart_top_1 > .navbar-nav > li > a.login-button, .main-header .login-button:hover,.sidemenu-login .login-button, .header-search-form .download_cat_filter, .header-search-form .search-btn::after, header .product-search-form .mayosis_vendor_cat,header .product-search-form .mayosel-select .current{color:#ffffff;}header.sticky,.header-master .to-flex-row,.main-header .maxcollapse,.maxcollapse-icon, .maxcollapse-submit{height:100px;}.header-master #mayosis-menu > ul > li > a,.header-master ul li.cart-style-one a.cart-button,.header-master ul li a.cart-button,.header-master .search-dropdown-main a,.main-header .maxcollapse,.maxcollapse-icon, .maxcollapse-submit,.header-master .my-account-menu > a{line-height:100px;}.mayosis-option-menu li a i, .mayosis-option-menu li i, .desktop-hamburger-item i, #mayosis-menu ul li a i{font-size:13px;}.header-top .to-flex-row{height:40px;}.header-top #mayosis-menu > ul > li > a,.header-top #top-main-menu > ul > li > a,.header-top ul li.cart-style-one a.cart-button, .header-top .mayosis-option-menu li{line-height:40px;}.header-top{background:#ffffff;}.header-top .to-flex-row,.header-top .burger{color:#28375a;}#top-main-menu > ul > li > a ,.top-header #cart-menu li a,.header-top #mayosis-menu > ul > li > a,.header-top #top-main-menu > ul > li > a,.header-top ul li.cart-style-one a.cart-button, .header-top .mayosis-option-menu li, #top-main-menu > ul > li > a > i , .top-header #cart-menu li a i,#top-main-menu ul li a i,.top-cart-menu li a i, .top-cart-menu li i,.header-top .to-flex-row i,.header-top .menu-item a{color:#28375a;}#top-main-menu ul ul a,.header-top .dropdown-menu li a,.header-top .mini_cart .widget .cart_item.empty .edd_empty_cart{color:#ffffff;}.header-top .mayosis-option-menu .mini_cart, #top-main-menu ul ul a,.header-top .mayosis-option-menu .my-account-list{background:#1e1e2d;}#top-main-menu ul ul:before,.header-top .cart_widget .mini_cart:before,#top-main-menu ul ul:after, .header-top .cart_widget .mini_cart:after,.header-top .mayosis-option-menu .my-account-list:before,.header-top .mayosis-option-menu .my-account-list:after{border-bottom-color:#1e1e2d;}#top-main-menu > ul > li > a > i , .top-header #cart-menu li a i,#top-main-menu ul li a i,.top-cart-menu li a i, .top-cart-menu li i,.header-top .to-flex-row i{font-size:12px;}.header-bottom{height:40px;background:#ffffff;color:#28375a;}.header-bottom,.header-bottom #mayosis-menu>ul>li>a{line-height:40px;}.header-bottom #mayosis-menu>ul>li>a,.header-bottom ul li.cart-style-one a.cart-button,.header-bottom .my-account-menu a{color:#28375a;}.header-bottom #mayosis-menu ul ul a,.header-bottom #mayosis-menu ul ul, .header-bottom .search-dropdown-main ul,.header-bottom .mayosis-option-menu .mini_cart,.header-bottom #mayosis-sidemenu > ul > li > a:hover, .header-bottom #mayosis-sidemenu > ul > li.active > a, .header-bottom #mayosis-sidemenu > ul > li.open > a,.header-bottom .my-account-menu .my-account-list,.header-bottom .my-account-list a{color:#ffffff;}.header-bottom #mayosis-menu ul ul, .header-bottom .search-dropdown-main ul,.header-bottom .mayosis-option-menu .mini_cart,.header-bottom #mayosis-sidemenu > ul > li > a:hover, .header-bottom #mayosis-sidemenu > ul > li.active > a, .header-bottom #mayosis-sidemenu > ul > li.open > a,.header-bottom .my-account-menu .my-account-list{background:#1e1e2d;}.header-bottom #mayosis-menu ul ul:before,.header-bottom .mayosis-option-menu .mini_cart:after,.header-bottom .my-account-menu .my-account-list:after{border-bottom-color:#1e1e2d;}header .sticky,header .fixedheader{background-color:#ffffff;}header .fixedheader #mayosis-menu > ul > li > a,header .fixedheader .cart-button, header .fixedheader .search-dropdown-main a,.sticky #mayosis-menu > ul > li > a,.sticky .cart-button, .sticky .search-dropdown-main a, header .fixedheader .cart-style-two .cart-button, .sticky .cart-style-two .cart-button,header .fixedheader .searchoverlay-button, .sticky .searchoverlay-button, header .fixedheader #menu-toggle, header .fixedheader .mobile_user > .navbar-nav > li > a, .sticky .mobile_user > .navbar-nav > li > a, header.fixedheader .login-button, .header-master.fixedheader .mayosis-option-menu.hidden-xs > .menu-item > a, .header-master.fixedheader .login-button{color:#28375a;}header .fixedheader #menu-toggle,header .fixedheader .mobile_user > .navbar-nav > li > a, .sticky .mobile_user > .navbar-nav > li > a, .header-master.fixedheader .login-button{border-color:#28375a;}header .fixedheader .burger span, header .fixedheader .burger span::before, header .fixedheader .burger span::after{background-color:#28375a;}.burger span, .burger span::before, .burger span::after,.burger.clicked span:before, .burger.clicked span:after{background-color:#ffffff;}a.mobile-cart-button{color:#ffffff;}#menu-toggle,.mobile--nav-menu > .navbar-nav > li > a, #sidebar-wrapper .navbar-nav > li > a, #sidebar-wrapper #mega-menu-wrap-main-menu #mega-menu-main-menu > li.mega-menu-item > a.mega-menu-link,.mobile--nav-menu a,#sidebar-wrapper .dropdown-menu > li > a,.mobile--nav-menu a, .mobile--nav-menu>#mayosis-sidemenu>ul>li>a,.mobile--nav-menu ,.mobile--nav-menu .menu-item a,.mobile-menu-main-part #mayosis-sidemenu a,.top-part-mobile a,.bottom-part-mobile a{color:#ffffff;}#menu-toggle,.mobile_user > .navbar-nav > li > a,.mobile--nav-menu .holder::after{border-color:#ffffff;}#mayosis-menu > ul > li > a,.header-master .main-header ul li.cart-style-one a.cart-button,.search-dropdown-main a,.header-master .menu-item a,.header-master .cart-style-two .cart-button,.my-account-list>li>a ,.header-master .burger,.header-master .cart-button, .cart_top_1>.navbar-nav>li>a.cart-button,.header-master .my-account-menu a{color:#ffffff;}#mayosis-menu ul ul,.search-dropdown-main ul,.mayosis-option-menu .mini_cart,#mayosis-sidemenu > ul > li > a:hover, #mayosis-sidemenu > ul > li.active > a, #mayosis-sidemenu > ul > li.open > a, .my-account-menu .my-account-list{background:#5000ce;}.search-dropdown-main ul:after,.header-master .mayosis-option-menu .mini_cart:after,.header-master .my-account-menu .my-account-list:after,#mayosis-menu ul ul:before{border-bottom-color:#5000ce;}#mayosis-menu ul ul,.header-master .dropdown-menu li a,#mayosis-menu ul ul a,.header-master.fixedheader .dropdown-menu li a{color:#ffffff;}.stylish-input-group input.dm_search{-webkit-border-radius:3px;-moz-border-radius:3px;border-radius:3px;}.header-search-form{width:360px;}.header-search-form input[type=search], .header-search-form input[type=text], .header-search-form select,.header-search-form .search-btn, .header-search-form .mayosel-select,.header-search-form .search-btn::after{height:40px;max-height:40px;}.header-search-form .search-btn::after{line-height:40px;}.main-header .login-button{background:rgba(0,0,0,.0);border-color:rgba(255,255,255,0.25);color:#ffffff;}body,.fes-form.fes-submission-form-div,.fes-fields table,#fes-vendor-dashboard table,#fes-product-list tbody tr td,.fes-profile-form{background:#ffffff;}.fes-form.fes-submission-form-div,.fes-fields table,#fes-vendor-dashboard table,#fes-product-list tbody tr td,.fes-profile-form{border-color:#ffffff;}.bottom-post-footer-widget,.post-view-style,.post-promo-box,.sidebar-theme,.author_meta_single,.single_author_post,.sidebar-product-widget,.single-blog-widget, blockquote,table,pre, .fes-fields textarea,.single--author--content,.jssortside,#mayosisone_1,#mayosis_side,.theme--sidebar--widget{background:#e9edf7;}table#edd_purchase_receipt, table#edd_purchase_receipt_products,table,pre,code{border-color:#e9edf7;}#commentform input[type=submit],.slider_dm_v .carousel-indicators .active, #edd-purchase-button,.edd-submit,input.edd-submit[type="submit"], .dm_register_button,.back-to-top:hover,button.fes-cmt-submit-form,.mini_cart .cart_item.edd_checkout a,.photo-image-zoom, a.edd-wl-button.edd-wl-save.edd-wl-action, .wishlist-with-bg .edd-wl-button.edd-wl-action, .edd-wl-create input[type=submit], .edd-wl-item-purchase .edd-add-to-cart-from-wish-list,.button-sub-right .btn, .wpcf7-submit,.status-publish.sticky:before, .footer-link-page-post .footer-page-post-link,.lSSlideOuter .lSPager.lSpg > li:hover a, .lSSlideOuter .lSPager.lSpg > li.active a,.lSSlideOuter .lSPager.lSpg > li a,.edd-submit.button.blue, .single-cart-button a.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js, .single-news-letter .nl__item--submit:hover,.edd-submit.button.blue:hover, .single-cart-button a:hover.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js:hover,#commentform input[type=submit]:hover,#sidebar-wrapper a#menu-close,#sidebar-wrapper a#menu-close:hover,.mini_cart .main_widget_checout,#basic-user-avatar-form input[type="submit"],#edd_profile_editor_submit,#basic-user-avatar-form input[type="submit"]:hover,#edd_profile_editor_submit:hover,.styleone.btn,.single-product-buttons .multiple_button_v,.button_accent,.fes-url-choose-row .edd-submit.upload_file_button,table.multiple tfoot tr th .edd-submit.insert-file-row{background:#5a00f0;}#commentform input[type=submit],.slider_dm_v .carousel-indicators .active, #edd-purchase-button,.edd-submit,input.edd-submit[type="submit"], .dm_register_button,.back-to-top:hover,button.fes-cmt-submit-form,.mini_cart .cart_item.edd_checkout a,.photo-image-zoom, a.edd-wl-button.edd-wl-save.edd-wl-action, .wishlist-with-bg .edd-wl-button.edd-wl-action, .edd-wl-create input[type=submit], .edd-wl-item-purchase .edd-add-to-cart-from-wish-list,.carousel-indicators li,blockquote, #wp-calendar caption,.edd_discount_link, #edd-login-account-wrap a, #edd-new-account-wrap a,.edd-submit.button.blue, .single-cart-button a.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js, .single-news-letter .nl__item--submit:hover,.edd-submit.button.blue:hover, .single-cart-button a:hover.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js:hover,#commentform input[type=submit]:hover,#sidebar-wrapper a#menu-close,#sidebar-wrapper a#menu-close:hover,.mini_cart .main_widget_checout,#basic-user-avatar-form input[type="submit"],#edd_profile_editor_submit,#basic-user-avatar-form input[type="submit"]:hover,#edd_profile_editor_submit:hover,.styleone.btn,.single-product-buttons .multiple_button_v,.button_accent,.fes-url-choose-row .edd-submit.upload_file_button,table.multiple tfoot tr th .edd-submit.insert-file-row{border-color:#5a00f0;}p a,.post-viewas> .nav-pills>li.active>a, .post-viewas>.nav-pills>li.active>a:focus, .post-viewas>.nav-pills>li.active>a:hover,.fourzerofour-info a,a:hover, .sidebar-blog-categories ul li:hover, .sidebar-blog-categories ul li:hover a,.dm_comment_author a, .single-user-info ul li:first-child a:hover,.mayosis-popup .close:hover,.edd_price_options.edd_single_mode ul li label input:checked~span.edd_price_option_name:before,.user-info a:hover,.product-title a:hover,.sidebar-blog-categories ul li:hover, .post-promo-box .single-blog-title a:hover, .edd_download_purchase_form .edd_price_options li.item-selected label, .favorited .glyphicon-add,.mayosel-select .option.selected,#today a,#edd_payment_mode_select_wrap input[type="radio"]:checked::before,.edd_cart_footer_row .edd_cart_total,#edd_checkout_form_wrap input[type=radio]:checked::before, #wp-calendar caption,.edd_discount_link, #edd-login-account-wrap a, #edd-new-account-wrap a,.main-post-promo .single-user-info ul li a:hover,.post-viewas> .nav-pills>li.active>a,.post-viewas> .nav-pills>li>a:hover,.button_ghost.button_accent,.button_link.button_accent,.button_ghost.button_accent:hover,.block-hover:hover,.main_content_licence.youcan table tr td .icon-background1 ,.fes-widget--metabox a,{color:#5a00f0;}.common-paginav a.next:hover,.common-paginav a.prev:hover,.common-paginav a.page-numbers:hover, .common-paginav span.page-numbers:hover,#edd_download_pagination a.page-numbers:hover,#edd_download_pagination span.page-numbers:hover,#edd_download_pagination span.page-numbers.current:hover,.button-fill-color:hover,.licence_main_title.youcantitle,input[type="submit"],input[type="submit"].wpcf7-submit{background:#5a00f0;}.common-paginav a.next:hover,.common-paginav a.prev:hover,.common-paginav a.page-numbers:hover, .common-paginav span.page-numbers:hover,#edd_download_pagination a.page-numbers:hover,#edd_download_pagination span.page-numbers:hover,#edd_download_pagination span.page-numbers.current:hover,p.comment-form-comment textarea:focus,#commentform input[type=text]:focus, #commentform input[type=email]:focus, p.comment-form-comment textarea:focus,#edd_login_form .edd-input:focus, #edd_register_form .edd-input:focus,#edd_checkout_form_wrap input.edd-input:focus, #edd_checkout_form_wrap textarea.edd-input:focus,#edd_checkout_form_wrap select.edd-select:focus,#edd_profile_editor_form input:not([type="submit"]):focus,#edd_profile_editor_form select:focus,.dasboard-tab,#contact textarea:focus, .wpcf7-form-control-wrap textarea:focus,input[type="text"]:focus, input[type="email"]:focus, input[type="password"]:focus,.solid-input input:focus,.product-search-form input[type="text"]:focus, .product-search-form input[type="search"]:focus,.button-fill-color:hover,.licence_main_title.youcantitle,input[type="submit"].wpcf7-submit{border-color:#5a00f0;}p.comment-form-comment textarea:hover,#commentform input[type=text]:hover, #commentform input[type=email]:hover, p.comment-form-comment textarea:hover,#edd_login_form .edd-input:hover, #edd_register_form .edd-input:hover,#edd_checkout_form_wrap input.edd-input:hover, #edd_checkout_form_wrap textarea.edd-input:hover,#edd_checkout_form_wrap select.edd-select:hover,#edd_profile_editor_form input:not([type="submit"]):hover,#edd_profile_editor_form select:hover,.dasboard-tab,#contact textarea:hover, .wpcf7-form-control-wrap textarea:hover,input[type="text"]:hover, input[type="email"]:hover, input[type="password"]:hover,.solid-input input:hover,.product-search-form input[type="text"]:hover, .product-search-form input[type="search"]:hover{border-bottom-color:#5a00f0;}#commentform input[type=submit],.slider_dm_v .carousel-indicators .active, #edd-purchase-button,.edd-submit,input.edd-submit[type="submit"], .dm_register_button,.back-to-top:hover,button.fes-cmt-submit-form,.mini_cart .cart_item.edd_checkout a,.photo-image-zoom, a.edd-wl-button.edd-wl-save.edd-wl-action, .wishlist-with-bg .edd-wl-button.edd-wl-action, .edd-wl-create input[type=submit], .edd-wl-item-purchase .edd-add-to-cart-from-wish-list,header .product-search-form .mayosel-select .current, a.edd-wl-button.edd-wl-save.edd-wl-action span, .edd-wl-item-purchase .edd-add-to-cart-from-wish-list span,.button-sub-right .btn, .wpcf7-submit,.status-publish.sticky:before, .footer-link-page-post .footer-page-post-link,.lSSlideOuter .lSPager.lSpg > li:hover a, .lSSlideOuter .lSPager.lSpg > li.active a,.lSSlideOuter .lSPager.lSpg > li a,.button_accent,input[type="submit"],input[type="submit"].wpcf7-submit,.fes-url-choose-row .edd-submit.upload_file_button,table.multiple tfoot tr th .edd-submit.insert-file-row{color:#ffffff;}.button_ghost.button_accent:hover,.block-hover:hover{background:#ffffff;border-color:#ffffff;}.edd-submit.button.blue, .single-cart-button a.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js, .single-news-letter .nl__item--submit:hover,.edd-submit.button.blue:hover, .single-cart-button a:hover.btn, .edd_purchase_submit_wrapper a.edd-add-to-cart.edd-has-js:hover,#commentform input[type=submit]:hover,#sidebar-wrapper a#menu-close,#sidebar-wrapper a#menu-close:hover,.mini_cart .main_widget_checout,#basic-user-avatar-form input[type="submit"],#edd_profile_editor_submit,#basic-user-avatar-form input[type="submit"]:hover,#edd_profile_editor_submit:hover,.styleone.btn,.single-product-buttons .multiple_button_v,.button-fill-color:hover,.licence_main_title.youcantitle{color:#ffffff;}.single_author_box, .page_breadcrumb, #searchoverlay ,.overlay,#mayosis-sidebar .mayosis-sidebar-header,h2#sitemap_pages,.mobile--nav-menu,.grid--download--categories a.cat--grid--main::after,.fes_dashboard_menu,.sidebar-search #icon-addon,.edd-fd-button,#edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue,#edd_checkout_cart .edd-submit.button.blue,.mayosis-collapse-btn,#menu-toggle:hover,a.mobile-cart-button:hover,a.mobile-login-button:hover,#sidebar-wrapper,.modal-backdrop,.mayosis-main-media .mejs-controls,.mayosis-main-media .mejs-container, #edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue:hover,.fourzerofour-info, #edd_profile_name_label, #edd_profile_billing_address_label, #edd_profile_password_label, .styletwo.btn,.transbutton.btn:hover,.mayosisonet101,.social_share_widget a:hover,.social-button-bottom a:hover i, h2.reciept_heading,.fill .btn,#fes-comments-table tr.heading_tr,#fes-product-list thead,#edd_user_commissions_overview table tr th, #edd_user_commissions_paid thead tr th,#fes-order-list thead tr th, #edd_user_revoked_commissions_table thead tr th, #edd_user_unpaid_commissions_table thead tr th,.photo--template--button:hover, .author--box--btn .follow--au--btn a, .author--box--btn .contact--au--btn a:hover,.title--button--box .btn.title--box--btn.transparent:hover{background:#282837;}.sidebar-search #icon-addon,.edd-fd-button,#edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue,#edd_checkout_cart .edd-submit.button.blue,.mayosis-collapse-btn,#menu-toggle:hover,a.mobile-cart-button:hover,a.mobile-login-button:hover,#sidebar-wrapper,.modal-backdrop,.mayosis-main-media .mejs-controls,.mayosis-main-media .mejs-container, #edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue:hover,.fourzerofour-info, #edd_profile_name_label, #edd_profile_billing_address_label, #edd_profile_password_label, .styletwo.btn,.transbutton.btn:hover,.mayosisonet101,.social_share_widget a:hover,.social-button-bottom a:hover i, h2.reciept_heading,.fill .btn,#fes-comments-table tr.heading_tr,#fes-product-list thead,#edd_user_commissions_overview table tr th, #edd_user_commissions_paid thead tr th,#fes-order-list thead tr th, #edd_user_revoked_commissions_table thead tr th, #edd_user_unpaid_commissions_table thead tr th,.photo--template--button:hover, .author--box--btn .follow--au--btn a, .author--box--btn .contact--au--btn a:hover,.transbutton.btn,.post-viewas> .nav-pills>li>a,.button_ghost.button_secaccent:hover{border-color:#282837;}.transbutton.btn,.post-viewas> .nav-pills>li>a,.author--box--btn .contact--au--btn a,.button_ghost.button_secaccent,.button_link.button_secaccent, nav.fes-vendor-menu ul li.active a, nav.fes-vendor-menu ul li:hover a{color:#282837;}.button_secaccent{background-color:#282837;}.button_secaccent,.button_ghost.button_secaccent:hover{border-color:#282837;}#edd_checkout_cart a.edd-cart-saving-button.edd-submit.button.blue:hover,.fourzerofour-info, #edd_profile_name_label, #edd_profile_billing_address_label, #edd_profile_password_label, .styletwo.btn,.transbutton.btn:hover,.mayosisonet101,.social_share_widget a:hover,.social-button-bottom a:hover i, h2.reciept_heading,.fill .btn,#fes-comments-table tr.heading_tr,#fes-product-list thead,#edd_user_commissions_overview table tr th, #edd_user_commissions_paid thead tr th,#fes-order-list thead tr th, #edd_user_revoked_commissions_table thead tr th, #edd_user_unpaid_commissions_table thead tr th,.photo--template--button:hover, .author--box--btn .follow--au--btn a, .author--box--btn .contact--au--btn a:hover, #searchoverlay .search input,#searchoverlay .search span,#searchoverlay .search input, #searchoverlay .search input::placeholder,#searchoverlay .close,.overlay,.title--button--box .btn.title--box--btn.transparent:hover{color:#ffffff;}#searchoverlay .search input,#searchoverlay .search span,#searchoverlay .search input, #searchoverlay .search input::placeholder,#searchoverlay .close,.overlay{border-color:#ffffff;}h2.page_title_single,.sep,.page_breadcrumb .breadcrumb > .active,.page_breadcrumb .breadcrumb a,#menu-toggle:hover,a.mobile-cart-button:hover,a.mobile-login-button:hover,#sidebar-wrapper,.overlay_content_center a.overlay_cart_btn,.overlay_content_center a.overlay_cart_btn:hover,.widget-posts .overlay_content_center a i, .bottom-widget-product .overlay_content_center a i,.breadcrumb a,.breadcrumb > .active,.grid--download--categories a, nav.fes-vendor-menu ul li a,.button_secaccent,.button_ghost.button_secaccent:hover,.button_text,.button_ghost.button_text:hover{color:#ffffff;}body,h1,h2,h3,h4,h5,h6,a,.mayosis-play--button-video:focus,.mayosis-play--button-video,.mayosel-select,textarea,.title--button--box .btn.title--box--btn.transparent{color:#28375a;}.sidebar-theme ul li a,.bottom-widget-product a,.total-post-count p,.author_single_dm_box p, .author_single_dm_box a,.author_meta_single h2 a,.author_meta_single p,.author_meta_single a, .author_meta_single ul li a,.comment-content p,a.sigining-up,.edd-lost-password a,.edd-login-remember span,.promo_price,#edd_checkout_cart th,#edd_checkout_form_wrap legend,#edd_checkout_wrap #edd_checkout_form_wrap label, #edd_checkout_form_wrap span.edd-description,span.edd_checkout_cart_item_title,#edd_checkout_cart .edd_cart_header_row th,#edd_checkout_cart td,#edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input, #edd_checkout_form_wrap span.edd-required-indicator,#edd_checkout_form_wrap select.edd-select,.single-user-info ul li a,.stylish-input-group button,.user-info span,.user-info a,.single_author_post,.empty_cart_icon i, .empty_cart_icon h2,.fourzerofour-area h1,.fourzerofour-area h3,#edd_profile_editor_form label,table tbody tr td,.mayosis-madalin .modal-header .close,.product-price h3,.sidebar-details p,.bottom-product-sidebar h4, .sidebar-blog-categories ul li a,.release-info .rel-info-value,.release-info .rel-info-tag,#edd_login_form .edd-input, #edd_register_form .edd-input,.grid-testimonal-promo .testimonial_details i.testimonial_queto_dm,.bottom_meta a, .dm_comment_author,.dm_comment-date,.comment--dot,.single-blog-title a,.single-blog-title,.top-header .top-social-icon li a:hover,code,.search-dropdown-main button,.post-promo-box.grid_dm .overlay_content_center a,a.edd-wl-action.edd-wl-button span, .photo--price--block a.edd-wl-action.edd-wl-button{color:#28375a;}.section-title,.product-meta a:hover,.maxcollapse-open .maxcollapse-input,.maxcollapse-open .maxcollapse-input::placeholder, .maxcollapse-open .maxcollapse-icon,#edd_show_discount,#edd_final_total_wrap,.bottom-product-sidebar h4,.sidebar-details h3 a, .bottom-product-sidebar .sidebar-details p,.bottom-widget-product .product-price .edd_price,.sidebar-details h3,.sidebar-details h3 a, .sidebar-details p,.sidebar-blog-categories ul li a,.edd_price_options.edd_single_mode ul li label,.product-price h3,.single-user-info ul li a, .single-blog-title a,.single-blog-title,.user-info a,legend, pre, .header-search-form .download_cat_filter select option, .header-search-form .download_cat_filter:after,.prime-wishlist-fav a.edd-wl-action.edd-wl-button, .prime-wishlist-fav a.edd-wl-action.edd-wl-button:hover i,.prime-wishlist-fav a.edd-wl-action.edd-wl-button:hover span,.tag_widget_single ul li a,.sidebar-blog-categories ul li,#fes-save-as-draft{color:#28375a;}::-webkit-input-placeholder,::-moz-placeholder,#edd_checkout_form_wrap input.edd-input::placeholder,#edd_checkout_form_wrap textarea.edd-input::placeholder,#edd_login_form .edd-input::placeholder, #edd_register_form .edd-input::placeholder,sidebar-search input[type=search]::placeholder,.button_ghost.button_text,.button_link.button_text,nav.fes-vendor-menu ul li.active a{color:#28375a;}.icon-play{border-left-color:#28375a;}.ghost_button,.mayosel-select:after,#edd_user_history th,table#edd_checkout_cart tbody,#edd_checkout_cart input.edd-item-quantity,.rel-info-value p,.button_text,.button_ghost.button_text:hover,#fes-save-as-draft{border-color:#28375a;}.ghost_button:hover,.tag_widget_single ul li a:hover,.mayosis-title-audio .mejs-button>button,.button_text,.button_ghost.button_text:hover{background-color:#28375a;}.product-search-form .download_cat_filter .mayosel-select span.current,.product-search-form .download_cat_filter .mayosel-select:after{color:#ffffff;}.product-search-form .download_cat_filter .mayosel-select:after{border-color:#ffffff;}.footer-widget.mx-one{width:26%;}.footer-widget.mx-two{width:16%;}.footer-widget.mx-three{width:16%;}.footer-widget.mx-four{width:16%;}.footer-widget.mx-five{width:26%;}.footer-widget.mx-six{width:15%;}.default-product-template.product-main-header .single_main_header_products .edd-add-to-cart span{color:#ffffff;}.comment-button a.btn,.social-button{border-color:rgba(255,255,255,0.25);}.social-button a i{background-color:#ffffff;color:#000046;}.photo-template-author{margin-top:80px;}.prime-product-template h1.single-post-title{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:36px;font-weight:700;letter-spacing:-0.75px;line-height:45px;}.vendor--search--box input[type="text"]{-webkit-border-radius:20px;-moz-border-radius:20px;border-radius:20px;}body,table tbody tr td,table thead tr th, table tfoot tr td{font-family:Lato, Helvetica, Arial, sans-serif;font-size:16px;font-weight:400;line-height:30px;}h2.page_title_single{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:36px;font-weight:700;letter-spacing:-0.75px;line-height:45px;}h1.single-post-title{font-family:Lato, Helvetica, Arial, sans-serif;font-size:36px;font-weight:900;line-height:45px;}h1{font-family:Lato, Helvetica, Arial, sans-serif;font-size:36px;font-weight:900;letter-spacing:-0.75px;line-height:45px;}h2{font-family:Lato, Helvetica, Arial, sans-serif;font-size:30px;font-weight:900;letter-spacing:-0.5px;line-height:42px;}h3{font-family:Lato, Helvetica, Arial, sans-serif;font-size:24px;font-weight:900;line-height:36px;}h4{font-family:Lato, Helvetica, Arial, sans-serif;font-size:19px;font-weight:900;line-height:30px;}h5{font-family:Lato, Helvetica, Arial, sans-serif;font-size:16px;font-weight:900;line-height:24px;}h6{font-family:Lato, Helvetica, Arial, sans-serif;font-size:14px;font-weight:900;letter-spacing:0.5px;line-height:24px;}#mayosis-menu > ul > li > a,.main-header ul li.cart-style-one a.cart-button,.search-dropdown-main a,.menu-item a,.cart-style-two .cart-button{font-family:Lato, Helvetica, Arial, sans-serif;font-size:16px;font-weight:400;}#mayosis-menu ul ul{font-family:Lato, Helvetica, Arial, sans-serif;font-size:16px;font-weight:400;line-height:30px;}#top-main-menu > ul > li > a ,.top-header #cart-menu li a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:14px;font-weight:400;line-height:14px;}#top-main-menu ul ul a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:14px;font-weight:400;line-height:20px;}#sidebar-wrapper .navbar-nav > li > a, #sidebar-wrapper #mega-menu-wrap-main-menu #mega-menu-main-menu > li.mega-menu-item > a.mega-menu-link{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:14px;font-weight:400;line-height:20px;}#sidebar-wrapper .dropdown-menu > li > a{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Oxygen-Sans,Ubuntu,Cantarell,"Helvetica Neue",sans-serif;font-size:14px;font-weight:400;line-height:20px;}
</style>
<script type='text/javascript' src='https://quixlab.com/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='https://quixlab.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var cnArgs = {"ajaxurl":"https:\/\/quixlab.com\/wp-admin\/admin-ajax.php","hideEffect":"fade","onScroll":"","onScrollOffset":"100","cookieName":"cookie_notice_accepted","cookieValue":"true","cookieTime":"2592000","cookiePath":"\/","cookieDomain":"","redirection":"","cache":"","refuse":"no","revoke_cookies":"0","revoke_cookies_opt":"automatic","secure":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://quixlab.com/wp-content/plugins/cookie-notice/js/front.min.js?ver=1.2.46'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var teconce_vars = {"processing_error":"There was a problem processing your request.","login_required":"Oops, you must be logged-in to follow users.","logged_in":"false","ajaxurl":"https:\/\/quixlab.com\/wp-admin\/admin-ajax.php","nonce":"cad17b677b"};
/* ]]> */
</script>
<script type='text/javascript' src='https://quixlab.com/wp-content/plugins/mayosis-core/library/user-follow/js/follow.js?ver=5.1.1'></script>
<link rel='https://api.w.org/' href='https://quixlab.com/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://quixlab.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://quixlab.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.1.1" />
<meta name="generator" content="Easy Digital Downloads v2.9.11" />
    <script type="text/javascript">
      var ajaxurl = 'https://quixlab.com/wp-admin/admin-ajax.php';
    </script>
    

    <style>
                /**Common Style**/

    
            
        .tag_widget_single ul li a,.sidebar-blog-categories ul li,.title--box--btn.transparent{
            border-color:rgba(40,55,90,0.25) !important;
        }
       

               
       ::selection{
            background:#28375a;
        }
        
        ::-moz-selection {
            background:#28375a;
        }


        /** Primary color**/
      
         .mayosel-select .option:hover,
        .mayosel-select .option.focus{
            background-color:rgba(40,55,90,0.25) !important;
        }
        /** Secondary color**/
               
        .author--box--btn .contact--au--btn a{
            border-color:rgba(30,0,80,0.65) !important;
        }

      
        
        /** Form Field color**/

        
        p.comment-form-comment textarea,#edd_login_form .edd-input, #edd_register_form .edd-input,#edd_checkout_form_wrap input.edd-input, #edd_checkout_form_wrap textarea.edd-input,#edd_checkout_form_wrap select.edd-select,
        #edd_download_pagination a.page-numbers, #edd_download_pagination span.page-numbers,#edd_profile_editor_form input:not([type="submit"]),#edd_profile_editor_form select,#contact textarea,
        .wpcf7-form-control-wrap textarea,input[type="text"], input[type="email"], input[type="password"],.solid-input input, .common-paginav a.next,
        .common-paginav a.prev,#edd_download_pagination a.next,#edd_download_pagination  a.prev,.fes-pagination a.page-numbers,.fes-pagination span.page-numbers, .fes-product-list-pagination-container a.page-numbers,.fes-product-list-pagination-container
        span.page-numbers,.fes-fields input[type=email],.fes-fields input[type=password]
        ,.fes-fields textarea,.fes-fields input[type=url],.fes-fields input[type=text],.fes-vendor-comment-respond-form textarea,.fes-fields select,textarea,
        .vendor--search--box input[type="text"],
        .fes-fields .mayosel-select
        {
            background:transparent;
            border:solid rgba(40,55,90,0.25);
            border-width:2px;
        }
       
        .common-paginav a.next:hover,.common-paginav a.prev:hover,.common-paginav a.page-numbers:hover, .common-paginav span.page-numbers:hover,.common-paginav span.page-numbers.current,#edd_download_pagination a.next:hover,#edd_download_pagination a.prev:hover,#edd_download_pagination span.page-numbers.current:hover,#edd_download_pagination span.page-numbers.current,#edd_download_pagination a.page-numbers:hover,
        #edd_download_pagination span.page-numbers:hover,.fes-pagination a.page-numbers:hover,.fes-pagination span.page-numbers:hover,
        .fes-product-list-pagination-container a.page-numbers:hover,
        .fes-product-list-pagination-container span.page-numbers:hover,.fes-pagination span.page-numbers.current,.fes-product-list-pagination-container span.page-numbers.current {
            border-color:#28375a;
            background:#28375a !important;

        }
        
        #fes-product-list tbody tr,#fes-order-list tbody tr,
        #edd_user_paid_commissions_table tbody tr,
        #edd_user_revoked_commissions_table tbody tr,
        #edd_user_unpaid_commissions_table tbody tr{
            border-color:rgba(40,55,90,0.1);
        }
        .fes-ignore.button{
            border:solid rgba(40,55,90,0.25);
            border-width:2px;
            color:#28375a;
        }
        .fes-ignore.button:hover{
            background:#28375a;
        }
    
       
                .hover_effect_single,.hover_effect,figure.effect-dm2 figcaption{
            background-color:rgba(40,40,55,.8);
            color:#ffffff
        }
        figure.mayosis-fade-in figcaption{
            background-color:rgba(40,40,55,.8);
            color:#ffffff;
        }
        .button-fill-color{
            background-color:#ffffff;
            color:rgba(40,40,55,.8);
        }
        .download-count-hover,.product-hover-social-share .social-button a, .product-hover-social-share .social-button a i,.recent_image_block .overlay_content_center a,.fes--author--image--block .overlay_content_center a{
            color:#ffffff !important;
        }
        
        .overlay_content_center .live_demo_onh{
            border-color:#ffffff;
            color:#ffffff;
        }
        .overlay_content_center .live_demo_onh:hover{
            background-color:#ffffff;
            border-color:#ffffff;
            color:rgba(40,40,55,.8) !important;
        }
       
                /**End Common Style**/
        /**Header Style**/
                .header-master,#mayosis-sidebar,#mobileheader{
            background:rgba(255,255,255,0);
        }
               
        
        /**Header Form **/
                .fill .form-control,.stylish-input-group input,.search-field,.maxcollapse-open .maxcollapse-input,.photo--price--block a.edd-wl-action.edd-wl-button{
            background:transparent;
            border-color: #1e0050;
            border-width:2px;
        }
                .header-master .to-flex-row{
            padding-top:40px;
            padding-right:0px;
            padding-bottom:40px;
            padding-left:0px;
        }
        
                .main-header.header-transparent .header-content-wrap,.mobile-header.header-transparent,#mobileheader {
            background:rgba(255,255,255,0);
        }
                
                        header.fixedheader .site-logo img.main-logo,header.fixedheader .center-logo img.main-logo,header.fixedheader#mobileheader .mobile-logo{
            opacity:0;
            display:none !important;
        }
        .fixedheader.main-header .site-logo .sticky-logo,.fixedheader.main-header .center-logo .sticky-logo,#mobileheader.fixedheader .sticky-logo{
            display:inline-block;
            opacity:1;
        }
                
        /**End Header Style**/
        /**Menu Style**/
                #mayosis-menu> ul > li > a:hover,.my-account-menu a:hover{
            opacity:.5;
        }
               

       

       .searchoverlay-button{
            color:#28375a;
        }
       
      
      
        /**End Menu Style**/
        /**Footer Style**/
        .main-footer{
            padding-top:120px;
            padding-right:0px;
            padding-bottom:80px;
            padding-left:0px;
        }
                footer.main-footer{
            background: linear-gradient(190deg, #1e0051, #3b009e);
        }
        
        footer.main-footer:after{
            background: url(https://rebuilding.quixlab.com/wp-content/uploads/2019/02/footer-shape.png) 100% 100% no-repeat;
        }
                .main-blog-promo:after{
            background: url(https://themeplanet.club/wp-content/uploads/2018/04/ISO-Cube-Lines.png) 100% 100% no-repeat;
        }
                        .default-product-template.product-main-header:after{
            background: url(https://rebuilding.quixlab.com/wp-content/uploads/2019/01/footer-shape-1.png) 100% 100% no-repeat;
        }
                footer.main-footer,.footer-text,.footer-sidebar ul li a,.without-bg-social a,.mx-widget-counter h2,.main-footer a,.main-footer ul li a{
            color:#ffffff;
        }
        .footer-widget-title,.footer-sidebar .widget-title{
            color:#ffffff;
        }
        .main-footer .sidebar-blog-categories ul li a,.main-footer .recent_post_widget a,
        .main-footer .recent_post_widget p,.main-footer .widget-products a,.main-footer .widget-products p,.main-footer .sidebar-blog-categories ul li{
            color:#ffffff !important;
        }
        .additional-footer,div.wpcf7-validation-errors, div.wpcf7-acceptance-missing{
            border-color:#ffffff;
        }
        .back-to-top{
            background-color:#ffffff;
            border-color:#ffffff;
            color:#1e0050;
        }
        footer .social-profile a{
            background:#16003c;
        }
        .copyright-footer{
            background:#16003c;
            color:#ffffff;
        }
        .copyright-text,.copyright-footer a{
            color:#ffffff;
        }

        .footer-widget .sidebar-theme .single-news-letter .nl__item--submit{
            background-color:#ffffff;
            border-color:#ffffff;
            color:#1e0050;
        }
        .footer-widget input[type="text"], .footer-widget input[type="email"], .footer-widget input[type="password"],.footer-widget input[type="text"]::placeholder, .footer-widget input[type="email"]::placeholder, .footer-widget input[type="password"]::placeholder{
            color:#ffffff !important;
        }
                .footer-widget input[type="text"],.footer-widget input[type="email"],.footer-widget input[type="password"]{
            background:transparent !important;
            border-color:#ffffff !important;
            border-width:2px;
        }
                /**End Footer Style**/
        /**Widget Style**/


        .theme--sidebar--widget{
            padding: 10px 30px;
            border-radius:3px;
        }
        .theme--sidebar--widget  .widget-title{
            text-align:center;
            color:#ffffff;
            padding: 23px;
            margin: -10px -30px;
            margin-bottom: 20px;
        }
        .theme--sidebar--widget .input-group.sidebar-search,.theme--sidebar--widget .search-field{
            margin:20px 0;
        }
        .sidebar-theme .search-form input[type=search],.sidebar-theme input[type=text],.sidebar-theme input[type=email],.sidebar-theme input[type=password],.sidebar--search--blog .search-form input[type=search],.theme--sidebar--widget select,.theme--sidebar--widget .search-field{
            border-color:#28375a;
        }
        .theme--sidebar--widget .menu-item a{
            color:#28375a;
        }
        .theme--sidebar--widget .single-news-letter .nl__item--submit{
            background-color:#28375a !important;
            border-color:#28375a !important;
        }

        .product_widget_inside,.sidebar-theme ul{
            padding:0;
        }

        .sidebar-blog-categories {
            padding: 0;
            margin-bottom: 30px;
        }
        .release-info{
            padding:0 !important;
        }


                .widget-title,.post-tabs .nav-pills > li.active > a, .post-tabs .nav-pills > li.active > a:focus, .post-tabs .nav-pills > li.active > a:hover{
            background:#1e0046;
        }
                
        .solid--buttons-fx a{
            background:#1e0046  !important;
            border-color:#1e0046  !important;
            color:#ffffff  !important;
        }
        .ghost--buttons-fx a{
             border-color:rgba(30,0,70,0.25) !important;
            color:#1e0046 !important;
        }
        .ghost--buttons-fx a:hover{
            background:#1e0046 !important;
            border-color:#1e0046 !important;
            color:#ffffff !important;
        }
                .sidebar-theme .search-form input[type=search],.sidebar-theme input[type=text],.sidebar-theme input[type=email],.sidebar-theme input[type=password],.sidebar--search--blog .search-form input[type=search],.theme--sidebar--widget select{
            background-color:transparent;
            border-color:#1e0050;
            border-width:2px;
            color:#28375a;
        }
        
        .sidebar-theme .single-news-letter .nl__item--submit {
            background:#1e0050;
            border-color:#1e0050;
            color:#ffffff;
        }

        /**End Widget Style**/
        /**Start Product Style**/
                .product-box,.grid_dm figure{
            border-radius:3px;
        }
                .product-box,.dm-default-wrapper .edd_download_inner{
            background:rgba(255,255,255,0);
        }
        .product-meta{
            
             padding-top:0;
            padding-right:0;
            padding-bottom:0;
            padding-left:0;
        }
                .product-box .product-meta a, .product-box .product-meta,.product-box .count-download, .product-box .count-download .promo_price,.count-download span{
            color:#28375a;
        }
                .default-product-template.product-main-header{
            background: linear-gradient(135deg, #1e0064, #1e0046) !important;
        }
        
                .default-product-template.product-main-header .featuredimagebg{
            filter:blur(5px);
            transform:scale(1.1);
        }
        
                .default-product-template.product-main-header .featuredimagebg{
            transform: translateX(1px) scale(1.1);
            background-attachment: fixed !important;
        }
                
     /** prime Template **/

        

        
        .prime-product-template.product-main-header{
            background:#edf0f7 !important;
        }
        

        
                .prime-product-template.product-main-header .featuredimagebg{
            filter:blur(5px);
            transform:scale(1.1);
        }
        
        
        .prime-product-template.product-main-header,
        .prime-product-template.product-main-header .single_main_header_products,
        .prime-product-template.product-main-header .single_main_header_products h1,
        .prime-product-template.product-main-header .single_main_header_products span,
        .prime-product-template.product-main-header .single_main_header_products span a,
        .prime-product-template.product-main-header .single_main_header_products a,
        .prime-product-template.product-main-header .breadcrumb
        {
            color: #ffffff        }

        /** product Archive **/
        .product-archive-breadcrumb,.product-archive-breadcrumb .parchive-page-title {
            color:#ffffff;
            text-align:center;
        }
                .product-archive-breadcrumb{
            background: linear-gradient(-135deg, #1e0046, #1e0064);
        }
                
                        .featuredimageparchive{
            filter:blur(5px);
            transform:scale(1.1);
        }
                
                /**Start Blog Style**/
                .main-post-promo,.page_breadcrumb, .single_author_box, .archive_bredcrumb_header{
            background: linear-gradient(-135deg, #1e0046, #1e0064);
        }
        
                .featuredimagebgblog{
            filter:blur(10px);
            transform:scale(1.1);
        }
        
                .featuredimagebgblog{
            transform: translateX(1px) scale(1.1);
            background-attachment: fixed !important;
        }
        
                .main-post-promo .single--post--content a, .single--post--content,.main-post-promo h1.single-post-title,.product-style-one-meta,.product-style-one-meta a,.main-post-promo .single-user-info ul li.datearchive,.main-post-promo .single-post-breadcrumbs .breadcrumb a,.main-post-promo .single-user-info ul li a,.single-post-excerpt,.main-post-promo .single-social-button,.main-post-promo .single-social-button a i, .single-post-breadcrumbs .breadcrumb > .active,.main-post-promo .blog--layout--contents{
            color:#ffffff !important;
        }
        .breadcrumb > .active{
            color:#ffffff;
        }
        .comment-button a.btn,.social-button{
            color:#ffffff;
            border-color:;
        }
        .comment-button a.btn:hover{
            background-color:#ffffff !important;
            border-color:#ffffff !important;
            color:#000046 !important;
        }

        .ie8 .lblue, .lblue > span,.lblue.left-corner > span::before,.lblue.left-corner > span::after,.lblue.right-corner > span, .lblue.right-corner > span::before,.lblue.right-corner > span::after {
            background-color: #e6174b;
            background-image: -webkit-gradient(linear, left top, left bottom, from(#e6174b), to(#e6174b))!important;
            background-image: -webkit-linear-gradient(top, #e6174b,#e6174b) !important;
            background-image: -moz-linear-gradient(top, #e6174b, #e6174b) !important;
            background-image: -ms-linear-gradient(top, #e6174b, #e6174b) !important;
            background-image: -o-linear-gradient(top, #e6174b, #e6174b) !important;
            background-image: linear-gradient(to bottom, #e6174b, #e6174b) !important;
        }
        .lblue.left-edge::before {
            border-left-color: #b7133d !important;
            border-top-color: #b7133d !important;
        }
        .page_breadcrumb,.single_author_box,.archive_bredcrumb_header{
            padding-top:195px;
            padding-bottom:117px;
            padding-right:0px;
            padding-left:0px;
        }
        .main-post-promo,.product-archive-breadcrumb{
            padding-top:180px;
            padding-bottom:120px;
            padding-right:0px;
            padding-left:0px;
        }
        .default-product-template.product-main-header{
            padding-top:180px;
            padding-bottom:120px;
            padding-right:0px;
            padding-left:0px;
        }
        .prime-product-template.product-main-header{
            padding-top:80px;
            padding-bottom:80px;
            padding-right:0px;
            padding-left:0px;
        }
        .default-product-template.product-main-header,
        .default-product-template.product-main-header .single_main_header_products,
        .default-product-template.product-main-header .single_main_header_products h1,
        .default-product-template.product-main-header .single_main_header_products span a,.default-product-template.product-main-header .single_main_header_products span,
        .default-product-template.product-main-header .single_main_header_products a,.default-product-template.product-main-header .single_main_header_products .social-button span
        {
            color: #ffffff        }
        .custombuttonmain.btn{
            background:#3c465a !important;
            border-color:#3c465a !important;
        }


                .grid-testimonal-promo .testimonial_details{

            background:#5a00f0;
        }
        .arrow-down{
            border-top-color:#5a00f0;
        }
        
        .load-mayosis {
            background: linear-gradient(135deg, #5a0096, #00003c);
        }
        .loading.reversed li{
            background-color:#5a0096;
        }

        /**End Product Style**/
        .bottom_meta p a, .bottom_meta a{
            border-color:rgba(40,55,90,0.25);
            color:#28375a;
        }
        .bottom_meta p a:hover, .bottom_meta a:hover{
            background-color:#28375a;
        }

        .download_cat_filter,.search-btn::after,.download_cat_filter select option{
            background-color:#5a00f0;
            color:#ffffff;
        }
        .download_cat_filter:after{
            color:#ffffff;
        }
        .product-search-form select{
            color:#ffffff;
        }
        .product-search-form  .search-fields{
            background-color:#ffffff;
        }
        .product-search-form.style2 input[type="text"]{
            border-color:#ffffff !important;
        }
        .product-search-form  input[type="text"]{
            border-color:#5a00f0;
        }
        .download-template-download-photo-template{
            background:#e9ebf7;
        }
                .photo-template-author,.photo--section--image img {
            max-height: 750px;
        }
        .photo--section--image{
            height: 750px;
        }
        .photo-credential{
            min-height: 750px;
            max-height: 750px;
        }
        .photo--template--author--meta{
            position:absolute;
        }
        .photo-template-author {
            background: #fcfdff;
            -webkit-box-shadow: 0px 4px 32px 0px rgba(15, 20, 30, 0.08);
            -moz-box-shadow:    0px 4px 32px 0px rgba(15, 20, 30, 0.08);
            box-shadow:         0px 4px 32px 0px rgba(15, 20, 30, 0.08);
        }
        .photo--template--button{
            border-color:rgba(30,0,80,0.25);
            color:rgba(30,0,80,0.5);
        }
                        
          
 .header-ghost-form.header-search-form .download_cat_filter, .header-ghost-form.header-search-form select,.header-ghost-form.header-search-form input[type="text"],
 .header-ghost-form.header-search-form .mayosel-select,#edd_user_history td ,
 table#edd_purchase_receipt_products td
 {
     border-color:rgba(40,55,90,0.25) !important;
 }
 .header-ghost-form.header-search-form .search-btn::after,.vendor--search--box .search-btn::after{
     color:rgba(40,55,90,0.65) !important;
 }
 

    </style>

		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		<meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<!--[if lte IE 9]><link rel="stylesheet" type="text/css" href="https://quixlab.com/wp-content/plugins/js_composer/assets/css/vc_lte_ie9.min.css" media="screen"><![endif]-->		<style type="text/css" id="wp-custom-css">
			.tabbable-line>.nav-tabs>li {
    margin-bottom: -12px !important;
}
.wpas-form-group > label {
    width: 100%;
    float: left;
}
.single_main_header_products .edd_reviews_rating_box {
    text-align: left;
}
@media(min-width:991px){
	.datehub{
		padding-left:7px;
	}
}		</style>
		<noscript><style type="text/css"> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript></head>

<!-- Begin Main Layout --> 
<body class="error404 cookies-not-set wpb-js-composer js-comp-ver-5.6 vc_responsive">
    
    
    
    <div class="mayosis-wrapper">

          <header id="main-header" class="main-header header-stacked">
      	
<div class="header-master stickyenabled smartenble">
        <div class="container">
         
            
                <div class="to-flex-row  th-flex-flex-middle">
       
         <!-- Start Desktop Content -->
          <div class="to-flex-col th-col-left hidden-xs hidden-sm default-logo-box  flexleft">
             

                <div class="site-logo sticky-enabled">
        
              <a href="https://quixlab.com/" class="logo_box">
                  
                  <img src="https://quixlab.com/wp-content/uploads/2019/03/logo-w.png" class="img-responsive main-logo hidden-xs hidden-sm" alt=""/>
                  
                                    <img src="https://quixlab.com/wp-content/uploads/2019/03/logo-w.png" class="img-responsive main-logo hidden-md hidden-lg" alt=""/>
                  												<img src="https://quixlab.com/wp-content/uploads/2019/03/logo-1.png" class="img-responsive sticky-logo" alt=""/>
						 						 
						 </a>
						 
</div>

          </div>

         

          
          <div class="to-flex-col th-col-center hidden-xs hidden-sm flexleft">
            
              <div class="main-navigation text-right">                     
<div id="mayosis-menu" class="menu-new-menu-container"><ul id="menu-new-menu" class="menu"><li id="menu-item-2540" class="menu-item menu-item-type-taxonomy menu-item-object-download_category menu-item-has-children has-sub"><a href="https://quixlab.com/product/category/templates/">   <span class="menu-item-text">Templates</span></a>
<ul>
	<li id="menu-item-2548" class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/templates/admin-templates/">   <span class="menu-item-text">Admin Templates</span></a></li>
	<li id="menu-item-2547" class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/templates/ui-kits/">   <span class="menu-item-text">UI Kits</span></a></li>
	<li id="menu-item-2546" class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/templates/plugins/">   <span class="menu-item-text">Plugins</span></a></li>
</ul>
</li>
<li id="menu-item-2634" class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/bundle/">   <span class="menu-item-text">Bundle</span></a></li>
<li id="menu-item-2539" class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/freebies/">   <span class="menu-item-text">Freebies</span></a></li>
<li id="menu-item-2543" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent"><a href="https://quixlab.com/blog/">   <span class="menu-item-text">Blog</span></a></li>
<li id="menu-item-2671" class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://quixlab.com/submit-ticket/">   <span class="menu-item-text">Support</span></a></li>
</ul></div></div>         
          </div>

          
          <div class="to-flex-col th-col-right hidden-sm hidden-xs flexright">
           
              

	
	
	<ul id="cart-menu" class="mayosis-option-menu hidden-sm hidden-xs">
                        					
					<li class="dropdown cart_widget cart-style-one"><a href="#" data-toggle="dropdown" class="cart-button"><i class="zil zi-cart"></i> <span class="items edd-cart-quantity">0</span></a><ul role="menu" class="dropdown-menu mini_cart"><li class="widget"><div class="widget widget_edd_cart_widget"><p class="edd-cart-number-of-items" style="display:none;">Number of items in cart: <span class="edd-cart-quantity">0</span></p>
<ul class="edd-cart">

	<li class="cart_item empty"><span class="edd_empty_cart">Your cart is empty.</span></li>
<li class="cart_item edd-cart-meta edd_total" style="display:none;">Total: <span class="cart-total">&#36;0.00</span></li>
<li class="cart_item edd_checkout" style="display:none;"><a href="https://quixlab.com/checkout/">Checkout</a></li>

</ul>
</div> 
					</li></ul></li> 
					
				
		</ul>
		
		<ul class="mobile-cart hidden-md hidden-lg">
		<li class="cart-style-one"><a href="https://quixlab.com/checkout/" class="btn btn-danger btn-lg mobile-cart-button">
                        <i class="zil zi-cart"></i></a></li>
                        
        </ul>
                        	
<ul id="search-menu" class="mayosis-option-menu">


	<li class="dropdown search-dropdown-main">
            <a href="#"  data-toggle="dropdown"><i class="zil zi-search" aria-hidden="true"></i></a>
            <ul class="dropdown-menu">
                <li>
                <form role="search" method="get" class="search-form-none search-form-collapsed" action="https://quixlab.com/">
						                    <input  value="" placeholder="Type and Hit Enter" type="search" name="s" id="s" class="dm_search"   >
                        <button type="submit" value="Search">
                            <i class="zil zi-search" aria-hidden="true"></i>
                            <input type="hidden" name="post_type" value="download" />
                        </button>  
                        
                </form>
                </li>
              </ul>
          </li>


</ul><ul id="account-button" class="mayosis-option-menu hidden-xs hidden-sm">
    
<li class="menu-item">
            
                <a href="https://quixlab.com/login/" class="login-button"><i class="zil zi-user"></i> Login</a>
            </li>

</ul>

<div id="account-mob" class="mayosis-option-menu hidden-md hidden-lg">
     
		<div id="mayosis-sidemenu">
		  <ul>
               <li class="menu-item">
                <a href="https://quixlab.com/login/"><i class="zil zi-user"></i> Login</a>
            </li>
        </ul>
</div>
   
</div>           
          </div>

         <!-- End Desktop Content -->

         <!-- Start Mobile Content -->
         
          <div class="to-flex-col th-col-left hidden-md hidden-lg">
                    
                      

                <div class="site-logo sticky-enabled">
        
              <a href="https://quixlab.com/" class="logo_box">
                  
                  <img src="https://quixlab.com/wp-content/uploads/2019/03/logo-w.png" class="img-responsive main-logo hidden-xs hidden-sm" alt=""/>
                  
                                    <img src="https://quixlab.com/wp-content/uploads/2019/03/logo-w.png" class="img-responsive main-logo hidden-md hidden-lg" alt=""/>
                  												<img src="https://quixlab.com/wp-content/uploads/2019/03/logo-1.png" class="img-responsive sticky-logo" alt=""/>
						 						 
						 </a>
						 
</div>

                  
        </div>
                  
                  <div class="to-flex-col th-col-center hidden-md hidden-lg">
                    
                                        
                  </div>
    
    
          <div class="to-flex-col th-col-right hidden-md hidden-lg flexright">
            
              

	
	
	<ul id="cart-menu" class="mayosis-option-menu hidden-sm hidden-xs">
                        					
					<li class="dropdown cart_widget cart-style-one"><a href="#" data-toggle="dropdown" class="cart-button"><i class="zil zi-cart"></i> <span class="items edd-cart-quantity">0</span></a><ul role="menu" class="dropdown-menu mini_cart"><li class="widget"><div class="widget widget_edd_cart_widget"><p class="edd-cart-number-of-items" style="display:none;">Number of items in cart: <span class="edd-cart-quantity">0</span></p>
<ul class="edd-cart">

	<li class="cart_item empty"><span class="edd_empty_cart">Your cart is empty.</span></li>
<li class="cart_item edd-cart-meta edd_total" style="display:none;">Total: <span class="cart-total">&#36;0.00</span></li>
<li class="cart_item edd_checkout" style="display:none;"><a href="https://quixlab.com/checkout/">Checkout</a></li>

</ul>
</div> 
					</li></ul></li> 
					
				
		</ul>
		
		<ul class="mobile-cart hidden-md hidden-lg">
		<li class="cart-style-one"><a href="https://quixlab.com/checkout/" class="btn btn-danger btn-lg mobile-cart-button">
                        <i class="zil zi-cart"></i></a></li>
                        
        </ul>
                        	 <div  class="mobile--nav-menu">
       <div class="top-part-mobile to-flex-row">
            <div class="to-flex-col th-col-left">
                            </div>
            
            <div class="to-flex-col th-col-right">
                            </div>
        </div>
        
        <div class="mobile-menu-main-part">
            <div class="col-sm-12 col-xs-12">
                  <div id="mayosis-sidemenu" class="menu-new-menu-container"><ul id="menu-new-menu-1" class="menu"><li class="menu-item menu-item-type-taxonomy menu-item-object-download_category menu-item-has-children has-sub"><a href="https://quixlab.com/product/category/templates/">  <span class="menu-item-class">Templates</span></a>
<ul>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/templates/admin-templates/">  <span class="menu-item-class">Admin Templates</span></a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/templates/ui-kits/">  <span class="menu-item-class">UI Kits</span></a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/templates/plugins/">  <span class="menu-item-class">Plugins</span></a></li>
</ul>
</li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/bundle/">  <span class="menu-item-class">Bundle</span></a></li>
<li class="menu-item menu-item-type-taxonomy menu-item-object-download_category"><a href="https://quixlab.com/product/category/freebies/">  <span class="menu-item-class">Freebies</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent"><a href="https://quixlab.com/blog/">  <span class="menu-item-class">Blog</span></a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page"><a href="https://quixlab.com/submit-ticket/">  <span class="menu-item-class">Support</span></a></li>
</ul></div>            </div>
        </div>
       
       
        <div class="bottom-part-mobile to-flex-row">
            <div class="to-flex-col th-col-left">
                                            </div>
            
            <div class="to-flex-col th-col-right">
                            </div>
        </div>
    </div>
    <div class="overlaymobile"></div>
     <ul  class="mobile-nav">
     <li class="burger"><span></span></li>
     </ul>           
          </div>
<!-- End Mobile Content -->
      </div>
            
    </div>
</div><!-- .header-master -->

</header>

	<div class="row page_breadcrumb">
	    	<div class="container">
	    <div class="col-md-12 col-xs-12">
	<h2 class="page_title_single">Sorry!! Something Went Wrong!!!</h2>
						</div>
		</div>
		</div>
<section class="fourzerofour-area">
		<div class="container">
			<h1>40 + 4 = <span>404</span></h1>
			<h3>
				The Page You Are Looking For is Missing, Misspelled or Doesn&#039;t Exist!</h3>
			
		</div>
		<div class="fourzerofour-info container-fluid">
		    	<div class="container">
				<p>We are Sorry For This Inconvenience! Don&#039;t Worry!! <br>
					Our <a href="https://quixlab.com/"> Homepage</a> will Guide You Through All of Our Awesome Things, Or You Can Have A Quick Look at Our Products!!!</p>
			</div>
			</div>
	</section>

		<div class="clearfix"></div>
			<footer class="main-footer container-fluid">
			<div class="container">
				<div class="footer-row">

	<!-- Begin Footer Section-->
	
		
	
		
	
		
	
		<div class="footer-widget mx-one" >
        						<div class="footer-sidebar">	<div class="sidebar-theme">	
 <img src="https://quixlab.com/wp-content/uploads/2019/02/logo-w.png" alt="Footer Logo" class="img-responsive footer-logo"/>
						<p class="footer-text">Lorem ipsum dolor sit amet, sectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore!</p>
		
                   
                   
<div class="clearfix"></div>
</div>

	</div><div class="footer-sidebar"><div class="sidebar-theme"><div class="mx-widget-counter"><h2>0</h2><p>Total Downloads & Counting</p></div></div></div>				    </div>
    <div class="footer-widget mx-two" >
        					<div class="footer-sidebar"><h4 class="footer-widget-title">Company</h4><div class="menu-company-container"><ul id="menu-company" class="menu"><li id="menu-item-420" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-420"><a href="https://quixlab.com/about-us/">About Us</a></li>
<li id="menu-item-425" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-425"><a href="https://quixlab.com/our-team/">Our Team</a></li>
<li id="menu-item-424" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-424"><a href="https://quixlab.com/testimonials/">Testimonials</a></li>
<li id="menu-item-423" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-423"><a href="https://quixlab.com/site-map/">Sitemap</a></li>
<li id="menu-item-426" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-426"><a href="https://quixlab.com/contact/">Contact</a></li>
<li id="menu-item-2687" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2687"><a href="https://quixlab.com/submit-ticket/">Support</a></li>
</ul></div></div>				    </div>
	<div class="footer-widget mx-three" >
        					<div class="footer-sidebar"><h4 class="footer-widget-title">Products</h4><div class="menu-products-container"><ul id="menu-products" class="menu"><li id="menu-item-2551" class="menu-item menu-item-type-taxonomy menu-item-object-download_category menu-item-2551"><a href="https://quixlab.com/product/category/templates/admin-templates/">Admin Templates</a></li>
<li id="menu-item-2552" class="menu-item menu-item-type-taxonomy menu-item-object-download_category menu-item-2552"><a href="https://quixlab.com/product/category/templates/ui-kits/">UI Kits</a></li>
<li id="menu-item-2688" class="menu-item menu-item-type-taxonomy menu-item-object-download_category menu-item-2688"><a href="https://quixlab.com/product/category/templates/plugins/">Plugins</a></li>
<li id="menu-item-2550" class="menu-item menu-item-type-taxonomy menu-item-object-download_category menu-item-2550"><a href="https://quixlab.com/product/category/freebies/">Freebies</a></li>
</ul></div></div>				    </div>
    
    <div class="footer-widget mx-four" >
         					<div class="footer-sidebar"><h4 class="footer-widget-title">Others</h4><div class="menu-others-container"><ul id="menu-others" class="menu"><li id="menu-item-429" class="menu-item menu-item-type-post_type menu-item-object-page current_page_parent menu-item-429"><a href="https://quixlab.com/blog/">Blog</a></li>
<li id="menu-item-433" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-433"><a href="https://quixlab.com/terms-conditions/">Terms &#038; Conditions</a></li>
<li id="menu-item-431" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-431"><a href="https://quixlab.com/privacy-policy-2/">Privacy Policy</a></li>
<li id="menu-item-432" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-432"><a href="https://quixlab.com/refund-policy/">Refund Policy</a></li>
<li id="menu-item-2635" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-2635"><a href="https://quixlab.com/licencepage/">License</a></li>
</ul></div></div>				    </div>
    
    <div class="footer-widget mx-five" >
         					<div class="footer-sidebar">		<div class="sidebar-theme">
		<div class="single-product-widget">
			<h4 class="widget-title"><i class="zil zi-envelope" aria-hidden="true"></i> Subscribe </h4>
			<div class="details-table_subscribe">
				<div role="form" class="wpcf7" id="wpcf7-f82-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"></div>
<form action="/demo/corbin/profile.html#wpcf7-f82-o1" method="post" class="wpcf7-form" novalidate="novalidate">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="82" />
<input type="hidden" name="_wpcf7_version" value="5.1.1" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f82-o1" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="g-recaptcha-response" value="" />
</div>
<div class="single-news-letter">
<span class="wpcf7-form-control-wrap email"><input type="email" name="email" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email nl__item" aria-required="true" aria-invalid="false" placeholder="Your Email Address" /></span><br />
<button type="submit" class="nl__item--submit"><i class="zil zi-arrow-right"></i></button>
</div>
<div class="wpcf7-response-output wpcf7-display-none"></div></form></div>			</div>
	</div>
	</div>
		</div><div class="footer-sidebar">	<div class="sidebar-theme">	
 <!--- Start SVG Sprite --->
 <svg aria-hidden="true" style="position: absolute; width: 0; height: 0; overflow: hidden;" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><symbol id="mayosis-Discover" viewBox="0 0 51 32"><title>Discover</title><path fill="#fff" style="fill: var(--color1, #fff)" d="M0 0h51.2v32h-51.2v-32z"></path><path fill="#f48120" style="fill: var(--color2, #f48120)" d="M51.2 18.744c0 0-13.088 9.16-37.072 13.256h37.072v-13.256z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M9.568 13.216h-1.6v5.528h1.592c0.848 0 1.456-0.2 1.992-0.64 0.64-0.52 1.016-1.312 1.016-2.12-0.008-1.632-1.232-2.768-3-2.768zM10.84 17.368c-0.344 0.304-0.784 0.44-1.488 0.44h-0.296v-3.656h0.296c0.704 0 1.128 0.128 1.488 0.448 0.376 0.336 0.6 0.848 0.6 1.376s-0.224 1.064-0.6 1.392z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M13.064 13.216h1.088v5.528h-1.088v-5.528z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M16.816 15.336c-0.656-0.24-0.848-0.4-0.848-0.696 0-0.352 0.344-0.616 0.808-0.616 0.328 0 0.592 0.136 0.88 0.448l0.568-0.736c-0.464-0.408-1.024-0.616-1.64-0.616-0.984 0-1.744 0.68-1.744 1.584 0 0.76 0.352 1.152 1.376 1.52 0.424 0.152 0.64 0.248 0.752 0.312 0.216 0.144 0.328 0.336 0.328 0.576 0 0.448-0.36 0.784-0.848 0.784-0.52 0-0.936-0.256-1.184-0.736l-0.704 0.672c0.504 0.728 1.104 1.056 1.928 1.056 1.128 0 1.928-0.744 1.928-1.816 0-0.888-0.368-1.288-1.6-1.736z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M18.76 15.984c0 1.624 1.288 2.888 2.944 2.888 0.472 0 0.872-0.088 1.368-0.32v-1.272c-0.432 0.432-0.824 0.608-1.312 0.608-1.096 0-1.872-0.784-1.872-1.904 0-1.064 0.8-1.896 1.824-1.896 0.52 0 0.912 0.184 1.368 0.624v-1.272c-0.48-0.24-0.872-0.336-1.336-0.336-1.664-0.016-2.984 1.272-2.984 2.88z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M31.704 16.928l-1.488-3.712h-1.192l2.368 5.672h0.584l2.408-5.672h-1.176z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M34.88 18.744h3.088v-0.936h-2v-1.488h1.92v-0.944h-1.92v-1.224h2v-0.936h-3.088z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M42.272 14.848c0-1.032-0.72-1.632-1.976-1.632h-1.616v5.528h1.088v-2.224h0.144l1.504 2.224h1.336l-1.76-2.328c0.832-0.168 1.28-0.72 1.28-1.568zM40.088 15.76h-0.32v-1.672h0.336c0.68 0 1.048 0.28 1.048 0.816 0 0.56-0.368 0.856-1.064 0.856z"></path><path fill="#f48120" style="fill: var(--color2, #f48120)" opacity="0.65" d="M29.36 16c0 1.624-1.328 2.944-2.968 2.944s-2.968-1.32-2.968-2.944 1.328-2.944 2.968-2.944c1.64 0 2.968 1.32 2.968 2.944z"></path><path fill="#f48120" style="fill: var(--color2, #f48120)" d="M29.36 16c0 1.624-1.328 2.944-2.968 2.944s-2.968-1.32-2.968-2.944 1.328-2.944 2.968-2.944c1.64 0 2.968 1.32 2.968 2.944z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M42.968 13.424c0-0.096-0.064-0.152-0.184-0.152h-0.16v0.488h0.12v-0.192l0.136 0.192h0.144l-0.16-0.2c0.064-0.016 0.104-0.072 0.104-0.136zM42.76 13.488h-0.016v-0.128h0.024c0.056 0 0.088 0.024 0.088 0.064s-0.032 0.064-0.096 0.064z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M42.808 13.088c-0.24 0-0.424 0.192-0.424 0.424s0.192 0.424 0.424 0.424c0.232 0 0.424-0.192 0.424-0.424s-0.192-0.424-0.424-0.424zM42.808 13.864c-0.184 0-0.344-0.152-0.344-0.344s0.152-0.352 0.344-0.352c0.184 0 0.336 0.16 0.336 0.352 0 0.184-0.152 0.344-0.336 0.344z"></path></symbol><symbol id="mayosis-Mastercard" viewBox="0 0 51 32"><title>Mastercard</title><path fill="#fff" style="fill: var(--color1, #fff)" d="M0 0h51.2v32h-51.2v-32z"></path><path fill="#ea001b" style="fill: var(--color4, #ea001b)" d="M28.504 16c0 4.197-3.431 7.6-7.664 7.6s-7.664-3.403-7.664-7.6c0-4.197 3.431-7.6 7.664-7.6s7.664 3.403 7.664 7.6z"></path><path fill="#f79e1b" style="fill: var(--color5, #f79e1b)" d="M38.024 16c0 4.197-3.431 7.6-7.664 7.6s-7.664-3.403-7.664-7.6c0-4.197 3.431-7.6 7.664-7.6s7.664 3.403 7.664 7.6z"></path><path fill="#ff5f01" style="fill: var(--color6, #ff5f01)" d="M28.504 16c0 3.287-1.3 5.952-2.904 5.952s-2.904-2.665-2.904-5.952c0-3.287 1.3-5.952 2.904-5.952s2.904 2.665 2.904 5.952z"></path></symbol><symbol id="mayosis-Paypal" viewBox="0 0 51 32"><title>Paypal</title><path fill="#fff" style="fill: var(--color1, #fff)" d="M0 0h51.2v32h-51.2v-32z"></path><path fill="#1d3586" style="fill: var(--color7, #1d3586)" d="M31.032 13.36c-0.256-0.304-0.72-0.464-1.328-0.464h-1.824c-0.128 0-0.232 0.088-0.248 0.216l-0.736 4.64c-0.016 0.088 0.056 0.176 0.152 0.176h0.936c0.088 0 0.16-0.064 0.176-0.152l0.208-1.312c0.016-0.12 0.128-0.216 0.248-0.216h0.576c1.2 0 1.896-0.576 2.080-1.72 0.072-0.496-0.008-0.888-0.24-1.168zM29.912 14.592c-0.096 0.648-0.6 0.648-1.080 0.648h-0.272l0.192-1.216c0.008-0.072 0.072-0.128 0.152-0.128h0.128c0.328 0 0.64 0 0.8 0.184 0.088 0.12 0.112 0.288 0.080 0.512z"></path><path fill="#1d3586" style="fill: var(--color7, #1d3586)" d="M18.016 13.36c-0.256-0.304-0.72-0.464-1.328-0.464h-1.824c-0.128 0-0.232 0.088-0.248 0.216l-0.736 4.64c-0.016 0.088 0.056 0.176 0.152 0.176h0.872c0.128 0 0.232-0.088 0.248-0.208l0.2-1.248c0.016-0.12 0.128-0.216 0.248-0.216h0.576c1.2 0 1.896-0.576 2.080-1.72 0.072-0.504-0.008-0.896-0.24-1.176zM16.896 14.592c-0.096 0.648-0.6 0.648-1.080 0.648h-0.272l0.192-1.216c0.008-0.072 0.072-0.128 0.152-0.128h0.128c0.328 0 0.64 0 0.8 0.184 0.088 0.12 0.112 0.288 0.080 0.512z"></path><path fill="#1d3586" style="fill: var(--color7, #1d3586)" d="M22.136 14.576h-0.872c-0.072 0-0.136 0.056-0.152 0.128l-0.040 0.24-0.064-0.088c-0.192-0.272-0.608-0.36-1.032-0.36-0.968 0-1.792 0.728-1.952 1.744-0.080 0.504 0.032 0.992 0.328 1.328 0.264 0.312 0.648 0.44 1.104 0.44 0.776 0 1.208-0.496 1.208-0.496l-0.040 0.24c-0.016 0.088 0.056 0.176 0.152 0.176h0.784c0.128 0 0.232-0.088 0.248-0.216l0.472-2.968c0.024-0.088-0.048-0.168-0.144-0.168zM20.92 16.264c-0.088 0.496-0.48 0.824-0.984 0.824-0.256 0-0.456-0.080-0.584-0.232s-0.176-0.368-0.136-0.608c0.080-0.488 0.48-0.832 0.976-0.832 0.248 0 0.448 0.080 0.584 0.24 0.128 0.144 0.184 0.368 0.144 0.608z"></path><path fill="#1d3586" style="fill: var(--color7, #1d3586)" d="M35.16 14.576h-0.872c-0.072 0-0.136 0.056-0.152 0.128l-0.040 0.24-0.064-0.088c-0.192-0.272-0.608-0.36-1.032-0.36-0.968 0-1.792 0.728-1.952 1.744-0.080 0.504 0.032 0.992 0.328 1.328 0.264 0.312 0.648 0.44 1.104 0.44 0.776 0 1.208-0.496 1.208-0.496l-0.040 0.24c-0.016 0.088 0.056 0.176 0.152 0.176h0.784c0.128 0 0.232-0.088 0.248-0.216l0.472-2.968c0.016-0.088-0.056-0.168-0.144-0.168zM33.936 16.264c-0.088 0.496-0.48 0.824-0.984 0.824-0.256 0-0.456-0.080-0.584-0.232s-0.176-0.368-0.136-0.608c0.080-0.488 0.48-0.832 0.976-0.832 0.248 0 0.448 0.080 0.584 0.24 0.128 0.144 0.184 0.368 0.144 0.608z"></path><path fill="#1d3586" style="fill: var(--color7, #1d3586)" d="M26.792 14.576h-0.88c-0.080 0-0.16 0.040-0.208 0.112l-1.208 1.768-0.512-1.696c-0.032-0.104-0.128-0.176-0.24-0.176h-0.864c-0.104 0-0.176 0.104-0.144 0.2l0.968 2.816-0.912 1.272c-0.072 0.096 0 0.24 0.128 0.24h0.88c0.080 0 0.16-0.040 0.208-0.112l2.92-4.176c0.064-0.112-0.008-0.248-0.136-0.248z"></path><path fill="#1d3586" style="fill: var(--color7, #1d3586)" d="M37.176 12.904h-0.84c-0.072 0-0.136 0.056-0.152 0.128l-0.752 4.72c-0.016 0.088 0.056 0.176 0.152 0.176h0.752c0.128 0 0.232-0.088 0.248-0.216l0.736-4.64c0.024-0.088-0.048-0.168-0.144-0.168z"></path></symbol><symbol id="mayosis-Stripe" viewBox="0 0 51 32"><title>Stripe</title><path fill="#fff" style="fill: var(--color1, #fff)" d="M0 0h51.2v32h-51.2v-32z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M42.12 16.224c0-2.344-1.136-4.2-3.312-4.2-2.184 0-3.504 1.856-3.504 4.184 0 2.76 1.568 4.16 3.8 4.16 1.096 0 1.92-0.248 2.544-0.592v-1.848c-0.624 0.312-1.344 0.504-2.248 0.504-0.896 0-1.68-0.32-1.784-1.392h4.488c-0.008-0.112 0.016-0.592 0.016-0.816zM37.584 15.36c0-1.032 0.64-1.464 1.208-1.464 0.56 0 1.16 0.432 1.16 1.464h-2.368z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M31.76 12.024c-0.896 0-1.48 0.424-1.792 0.72l-0.12-0.568h-2.016v10.696l2.288-0.488 0.008-2.592c0.328 0.24 0.816 0.576 1.624 0.576 1.64 0 3.136-1.32 3.136-4.232-0.008-2.664-1.52-4.112-3.128-4.112zM31.208 18.352c-0.536 0-0.856-0.192-1.080-0.432l-0.016-3.408c0.24-0.264 0.568-0.456 1.096-0.456 0.84 0 1.416 0.936 1.416 2.136 0 1.232-0.568 2.16-1.416 2.16z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M24.664 11.48l2.304-0.488v-1.864l-2.304 0.488z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M24.664 12.176h2.304v8.032h-2.304v-8.032z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M22.2 12.856l-0.144-0.68h-1.984v8.032h2.288v-5.448c0.544-0.712 1.456-0.576 1.744-0.48v-2.104c-0.296-0.104-1.368-0.304-1.904 0.68z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M17.6 10.184l-2.24 0.472-0.008 7.352c0 1.36 1.024 2.36 2.384 2.36 0.752 0 1.304-0.136 1.608-0.304v-1.864c-0.296 0.12-1.736 0.536-1.736-0.816v-3.264h1.744v-1.952h-1.744l-0.008-1.984z"></path><path fill="#6772e5" style="fill: var(--color8, #6772e5)" d="M11.4 14.512c0-0.36 0.296-0.496 0.776-0.496 0.696 0 1.584 0.216 2.28 0.592v-2.16c-0.76-0.304-1.52-0.416-2.28-0.416-1.856 0-3.096 0.968-3.096 2.592 0 2.536 3.488 2.128 3.488 3.216 0 0.424-0.368 0.56-0.88 0.56-0.76 0-1.736-0.312-2.512-0.728v2.192c0.856 0.368 1.712 0.52 2.504 0.52 1.904 0 3.216-0.944 3.216-2.592 0.008-2.744-3.496-2.248-3.496-3.28z"></path></symbol><symbol id="mayosis-Visa" viewBox="0 0 51 32"><title>Visa</title><path fill="#fff" style="fill: var(--color1, #fff)" d="M0 0h51.2v32h-51.2v-32z"></path><path fill="#000" style="fill: var(--color3, #000)" d="M25.448 11.264l-2.048 9.504h-2.48l2.048-9.504h2.48zM35.88 17.4l1.304-3.568 0.752 3.568h-2.056zM38.648 20.76h2.296l-2-9.504h-2.112c-0.48 0-0.88 0.272-1.056 0.696l-3.72 8.8h2.608l0.52-1.416h3.184l0.28 1.424zM32.176 17.664c0.008-2.504-3.496-2.648-3.472-3.768 0.008-0.344 0.336-0.704 1.048-0.792 0.352-0.048 1.336-0.080 2.448 0.424l0.432-2.016c-0.6-0.216-1.368-0.416-2.32-0.416-2.456 0-4.176 1.288-4.192 3.136-0.016 1.368 1.232 2.128 2.168 2.584 0.968 0.464 1.288 0.768 1.288 1.184-0.008 0.64-0.768 0.92-1.48 0.928-1.248 0.016-1.968-0.336-2.544-0.6l-0.448 2.080c0.584 0.264 1.648 0.496 2.76 0.504 2.6 0 4.304-1.28 4.312-3.248zM21.904 11.264l-4.016 9.504h-2.624l-1.976-7.584c-0.12-0.464-0.224-0.64-0.592-0.832-0.592-0.32-1.584-0.624-2.448-0.808l0.056-0.272h4.216c0.536 0 1.024 0.352 1.144 0.968l1.048 5.496 2.576-6.464h2.616z"></path></symbol></defs></svg>
 
 <!--- End SVG Sprite --->
<!--- Payment Icon --->
<div class="payment-icons">
<svg class="mayosisicon mayosis-Paypal"><use xlink:href="#mayosis-Paypal"></use></svg>

 <svg class="mayosisicon mayosis-Stripe"><use xlink:href="#mayosis-Stripe"></use></svg>
  
  <svg class="mayosisicon mayosis-Visa"><use xlink:href="#mayosis-Visa"></use></svg>
    
    <svg class="mayosisicon mayosis-Mastercard"><use xlink:href="#mayosis-Mastercard"></use></svg>
  
  
 

 
 </div>
</div>

	</div>				    </div>
    
    
		
	
		
		
	
		
	</div>
		<div class="additional-footer">
	    <div class="additional-footer-widget">
    						<div class="footer-sidebar">			<div class="textwidget"><p>© Copyright 2019 Quixlab, All rights reserved!</p>
</div>
		</div>				</div>
<div class="additional-footer-widget">
    	</div>

<div class="additional-footer-widget">
    						<div class="footer-sidebar">  <div class="sidebar-theme">
		<h4 class="footer-widget-title"></h4>
            						<div class="without-bg-social" style="text-align:right">
                   							<a href="https://facebook.com/" class="facebook" target="_self"><i class="zil zi-facebook"></i></a>
														
							 							<a href="https://twitter.com/" class="twitter" target="_self"><i class="zil zi-twitter"></i></a>
														
							
														<a href="https://pinterest.com/" class="pinterest" target="_self"><i class="zil zi-pinterest"></i></a>
														
														<a href="https://instagram.com/" class="instagram" target="_self"><i class="zil zi-instagram"></i></a>
														
										            	
			            					            
				            				            
				            				            
				            				            
				             				            
				             				            
				             				            
				             						</div>
			<div class="clearfix"></div>
</div>
	</div>				</div>	 </div>
	 			</div>
		</footer>
	<!-- End Footer Section-->
</div>
</div>
	
	<a id="back-to-top" href="#" class="back-to-top" role="button"><i class="zil zi-chevron-up"></i></a>
	
<script type='text/javascript'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/quixlab.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://quixlab.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var edd_scripts = {"ajaxurl":"https:\/\/quixlab.com\/wp-admin\/admin-ajax.php","position_in_cart":"","has_purchase_links":"","already_in_cart_message":"You have already added this item to your cart","empty_cart_message":"Your cart is empty","loading":"Loading","select_option":"Please select an option","is_checkout":"0","default_gateway":"","redirect_to_checkout":"0","checkout_page":"https:\/\/quixlab.com\/checkout\/","permalinks":"1","quantities_enabled":"","taxes_enabled":"0"};
/* ]]> */
</script>
<script type='text/javascript' src='https://quixlab.com/wp-content/plugins/easy-digital-downloads/assets/js/edd-ajax.min.js?ver=2.9.11'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/bootstrap.min.js?ver=1.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/smoothscroll.min.js?ver=1.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-includes/js/hoverIntent.min.js?ver=1.8.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/theme.min.js?ver=1.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/youtube.min.js?ver=1.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/jquery.easing.min.js?ver=1.4.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/lity.min.js?ver=1.0.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/jquery.isotope.min.js?ver=1.5.6'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/sticky.js?ver=1.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/essential-theme.js?ver=1.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/sticky-sidebar-min.js?ver=1.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/modernizr.js?ver=2.7.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/jquery.parallax-scroll.js?ver=1.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/parallax.hover.js?ver=1.5'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/gallery.min.js?ver=1.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/themes/mayosis/js/gallery.main.js?ver=0.9.4'></script>
<script type='text/javascript'>
document.tidioChatCode = "jpm7ssmmbakwftrednfs15rqv86y9aeu";
</script>
<script type='text/javascript' src='//code.tidio.co/jpm7ssmmbakwftrednfs15rqv86y9aeu.js?ver=3.4.0'></script>
<script type='text/javascript' src='https://quixlab.com/wp-includes/js/wp-embed.min.js?ver=5.1.1'></script>
<script type='text/javascript' src='https://quixlab.com/wp-content/plugins/mayosis-core/library/kirki/modules/webfont-loader/vendor-typekit/webfontloader.js?ver=3.0.28'></script>
<script type='text/javascript'>
WebFont.load({google:{families:['Lato:400,900:cyrillic,cyrillic-ext,devanagari,greek,greek-ext,khmer,latin,latin-ext,vietnamese,hebrew,arabic,bengali,gujarati,tamil,telugu,thai']}});
</script>

			<div id="cookie-notice" role="banner" class="cn-bottom bootstrap" style="color: #fff; background-color: #000;"><div class="cookie-notice-container"><span id="cn-notice-text">We use cookies to ensure that we give you the best experience on our website. If you continue to use this site we will assume that you are happy with it.</span><a href="#" id="cn-accept-cookie" data-cookie-set="accept" class="cn-set-cookie cn-button bootstrap button">Ok</a>
				</div>
				
			</div></body>
<!-- End Main Layout --> 

</html>